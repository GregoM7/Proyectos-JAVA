package com.company;

public class Departamento extends Proyecto implements Comparable {
    private Integer cantidadDePisos;
    private Integer pisosPorDepartamento;

    public Departamento(Integer numeroProyecto, String nombreProyecto, String ciudad, String status, Construccion construccion, Integer cantidadDePisos, Integer pisosPorDepartamento) {
        super(numeroProyecto, nombreProyecto, ciudad, status, construccion);
        this.cantidadDePisos = cantidadDePisos;
        this.pisosPorDepartamento = pisosPorDepartamento;
    }

    @Override
    public int compareTo(Object o) {
        Departamento departamento = (Departamento) o;
        Integer piso1 = cantidadDePisos *pisosPorDepartamento;
        Integer piso2 = departamento.cantidadDePisos* departamento.pisosPorDepartamento;
        if (piso1 > piso2) {
            return 1; //Mayor
        }
        if (piso1 < piso2) {

            return -1; //Menor
        }return 0; //Son iguales
    }

    public Boolean esRascacielos(){
        if(cantidadDePisos > 15){
            return true;
        }else{
            return false;
        }
    }

}
